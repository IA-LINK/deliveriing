from django.contrib import admin

from . models import *




admin.site.register(Biodata)
admin.site.register(Academic_Details)
admin.site.register(Utme)
admin.site.register(O_Level_Result)
admin.site.register(Event)