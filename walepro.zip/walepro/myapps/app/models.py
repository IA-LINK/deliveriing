from django.db import models

class Biodata(models.Model):
    SurName = models.CharField(max_length=16)
    FirstName = models.CharField(max_length=16)
    OthersName = models.CharField(max_length=16)
    phone_number = models.CharField(max_length=32)
    Email_address = models.EmailField(blank=False)
    Gender = models.CharField(max_length=16)
    DOB = models.CharField(max_length=16)
    marital_status = models.CharField(max_length=16)
    nationality = models.CharField(max_length=32)
    state_of_origin = models.CharField(max_length=32)
    local_Government = models.CharField(max_length=32)
    home_town = models.CharField(max_length=32)
    place_of_birth = models.CharField(max_length=32)
    contact_address = models.CharField(max_length=32)
    
     
    def __str__(self):
        return self.SurName
    

class Academic_Details(models.Model):
    Jamb_Number = models.CharField(max_length=16)
    Course_of_Study_Choice = models.CharField(max_length=32)
    Department = models.CharField(max_length=60)
    Programme = models.CharField(max_length=32)
    Admission_Year = models.CharField(max_length=16)
    Mode_of_Entry = models.CharField(max_length=16)
    
    
    def __str__(self):
        return self.Jamb_Number
    
    
class Utme(models.Model):
    Jamb_Number = models.CharField(max_length=16)
    Jamb_Socre = models.CharField(max_length=16)
    Mode_of_Entry = models.CharField(max_length=16)
    Utme_Subjects = models.CharField(max_length=16)
    
    
    def __str__(self):
        return self.Jamb_Number



class O_Level_Result(models.Model):
    type_of_Result = models.CharField(max_length=16)
    number_of_Sittings = models.CharField(max_length=32)
    exams_Date = models.DateTimeField(auto_now_add=True)
    examination_Number = models.CharField(max_length=16)
    subjects = models.CharField(max_length=32)
    
    
    def __str__(self):
        return self.Type_of_Result



class Event(models.Model):
    title = models.CharField(max_length=16)
    slug = models.SlugField()
    body = models.TextField()
    created_Date = models.DateTimeField(auto_now_add=True)
    
    
    
    def __str__(self):
        return self.Event
    
    
    

