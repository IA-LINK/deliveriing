from django.shortcuts import render


def Home(request):
    return render(request,'home.html')
    
    
    
def Pre_NCE(request):
    return render(request,'Pre_NCE.html')


def About(request):
    return render(request, 'about.html')


def Event(request):
    return render(request, 'event.html')
